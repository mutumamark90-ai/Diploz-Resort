# Property imagery source notes

These photographs were retrieved through image search from public accommodation-listing galleries and are labeled as Diplozz Resort Kisii (not generated stock photography). They are included as a working visual set for this redesign and should be replaced with owner-supplied, licensed originals before public launch if permission cannot be confirmed.

- `resort-exterior.jpg`, `room-blue.jpg`: Hotels.com listing for Diplozz Resort Kisii (`https://www.hotels.com/ho3707249824/`)
- `resort-approach.jpg`, `bar-interior.jpg`, `room-lounge.jpg`, `room-detail.jpg`, `room-suite.jpg`: Tiket.com listing for Diplozz Resort Kisii (`https://tiket.com/en-us/hotel/kenya/diplozz-resort-kisii-805001746487413591`)
